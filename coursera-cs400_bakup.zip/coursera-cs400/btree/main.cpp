/**
 * An empty BinaryTree.
 * 
 * @author
 *   Wade Fagen-Ulmschneider <waf@illinois.edu>
 */

#include "BTree.h"

int main() {
  BTree<int> t;
  // ...

  return 0;
}