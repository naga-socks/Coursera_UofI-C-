/**
 * C++ program for a simple "Hello, world!"
 * 
 * @author
 *   Wade Fagen-Ulmschneider <waf@illinois.edu>
 */

#include <iostream>

int main() {
  std::cout << "Hello, world!" << std::endl;
  return 0;
}
